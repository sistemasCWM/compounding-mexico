15.0.1 ( Date : 07 September 2021 ) 
-----------------------------------

- Initial release

15.0.2 ( Date : 02 December 2021 )
----------------------------------

[Add] Currency symbol in Order line in message ( Sale, Purchase ).

15.0.3 ( Date : 29 March 2022 )
-------------------------------

[Fix] PO file not Properly Translated issue.

15.0.4 ( Date : 02 Jun 2022 )
-------------------------------

[Add] send by whattsapp feature in CRM.

15.0.5 (3rd April 2023)
----------------------------------

[Fix] : Fixed the issue of download in icognito 