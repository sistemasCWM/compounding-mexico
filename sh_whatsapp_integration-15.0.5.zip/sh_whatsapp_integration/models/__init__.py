# -*- coding: utf-8 -*-
# Part of Softhealer Technologies.

from . import base_model
from . import sale_order_inherit
from . import purchase_order_inherit
from . import customer_invoice_inherit
from . import stock_picking_inherit
from . import res_config_settings
from . import account_payment_inherit
from . import crm_lead_inherit
