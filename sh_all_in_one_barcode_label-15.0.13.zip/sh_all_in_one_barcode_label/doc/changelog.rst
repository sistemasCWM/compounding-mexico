15.0.1 (Date : 21st September 2021)
===================================
Initial Release

15.0.2 (Date : 16th October 2021)
===================================
[ADD] add two fields like sale price with tax and cost price with tax in product and variant tree,form view.

15.0.3 (Date : 27th October 2021)
========================================
[Fix]-Access rights bug

15.0.4 (Date : 9th November 2021)
------------------------------------------
[FIX] issue fixed of qr code label image.

15.0.5 (Date : 10th November 2021)
------------------------------------------
[UPDATE] changed sales and cost price include taxes field from monetary to float for currency symbol in label.

15.0.6 (Date : 11th November 2021)
---------------------------------------------
[FIX] Fixed Small error when print label.

15.0.7 (Date :4th December 2021)
---------------------------------------
[ADD] menu icon added.

15.0.8 (Date :28th December 2021)
----------------------------------------
[FIX] fix decimal point based on currency decimal point

15.0.9 (Date : 9th Febuary 2022)
----------------------------------------
[ADD] add pricelist field in lable template and show strike price in label

15.0.10 (Date : 12th May 2022)
-----------------------------------------
[ADD] Add company logo in label dynamically by configure logo height,width and align.

15.0.11 (Date : 3 Aug 2022)
-----------------------------------------
[ADD] Add selection field for Print Customer/Product fields in label(values like customer,product) then select field from product.product and res.partner respectively.

15.0.12 (Date : 30 Aug 2022)
-----------------------------------------
[ADD] boolean field for display strike price.

15.0.13 (Date : 14th Feb 2023)
-----------------------------------------
[ADD] Add lot/serial as a label as barcode or QR.