About
============
Every company has its own label standard. so our module is helps to make dynamic product labels. We provide 3 predefine templates for product label. You can generate dynamic product label templates. You can add customizable extra fields in the product label. We provide label print option from the products, sales/quotation, purchase/request for quotation, inventory/incoming order/delivery order/internal transfer, invoice/bill/credit note/debit note. You can print the bulk quantity of labels. Cheers!

Installation
============
1) Copy module files to addon folder.
2) Restart odoo service (sudo service odoo-server restart).
3) Go to your odoo instance and open apps (make sure to activate debug mode).
4) click on update app list. 
5) search module name and hit install button.

Softhealer Technologies Support Team
=====================================
Skype: live:softhealertechnologies
What's app: +917984575681
E-Mail: suppport@softhealer.com
Website: https://softhealer.com
