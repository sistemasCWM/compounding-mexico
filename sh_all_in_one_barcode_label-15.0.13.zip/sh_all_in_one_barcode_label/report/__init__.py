# -*- coding: utf-8 -*-
# Part of Softhealer Technologies.

from . import barcode_report
